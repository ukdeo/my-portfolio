// ═══════════════════════════════════════════════════════
// PORTFOLIO DATABASE & CONTENTS
// ═══════════════════════════════════════════════════════

const projects = [
  {
    title: "Bank Management System",
    desc: "A console-based banking application built in C handling account creation, balance checks, withdrawals, and user record management utilizing file-handling databases.",
    icon: "🏦",
    tags: ["C Language", "File I/O", "Console DB"],
    link: "https://github.com/ukdeo/bank-management-system"
  },
  {
    title: "E-Voting System",
    desc: "A secure, responsive voting interface built with Django and SQLite. Features administrative panels, voter authorization lists, real-time result calculations, and encryption.",
    icon: "🗳️",
    tags: ["Django", "SQLite3", "Security"],
    link: "https://github.com/ukdeo/e-voting-system"
  },
  {
    title: "Care Connect (Hackathon)",
    desc: "Award-winning healthcare connection platform matching critical patients with local services. Developed in React and Node.js during a 48-hour hackathon sprint.",
    icon: "🏥",
    tags: ["React", "Node.js", "Winner"],
    link: "https://github.com/ukdeo/care-connect"
  },
  {
    title: "Diabetes Health Checker",
    desc: "Machine learning classifier analyzing patient metrics (glucose levels, blood pressure, insulin) to predict diabetes probability. Includes a responsive Streamlit dashboard.",
    icon: "⚕️",
    tags: ["Python", "Scikit-Learn", "Streamlit"],
    link: "https://github.com/ukdeo/diabetes-checker"
  },
  {
    title: "Stock Price Prediction",
    desc: "LSTM recurrent neural network modeling and forecasting stock price fluctuations based on historical Yahoo Finance datasets. Built using TensorFlow and Docker.",
    icon: "📈",
    tags: ["TensorFlow", "LSTM", "Docker"],
    link: "https://github.com/ukdeo/stock-prediction"
  },
  {
    title: "Self-Healing Database",
    desc: "A fault-tolerant document database wrapper that automatically detects node failures, triggers data replication protocols, and restores backups with zero system down-time.",
    icon: "💾",
    tags: ["Python", "MongoDB", "Distributed"],
    link: "https://github.com/ukdeo/self-healing-db"
  },
  {
    title: "Habit Tracker Dashboard",
    desc: "A clean dashboard tool displaying daily habits, streak achievements, and graphical frequency charts. Developed with vanilla JavaScript and HTML5 localStorage APIs.",
    icon: "🧠",
    tags: ["JavaScript", "HTML5", "UI/UX"],
    link: "https://github.com/ukdeo/habit-tracker"
  },
  {
    title: "Space Shooter Arcade",
    desc: "Retro horizontal scrolling space game rendering dynamic asteroid collisions, laser firing loops, high score saves, and custom level difficulties inside HTML5 Canvas.",
    icon: "🚀",
    tags: ["Canvas API", "Audio", "Game Loops"],
    link: "https://github.com/ukdeo/space-shooter"
  }
];

const skills = [
  // Languages
  { name: "Python", cat: "Languages", level: "Expert", desc: "Used for ML modeling, distributed backends, and scripting.", color: "#f59e0b", shadow: "rgba(245,158,11,0.5)" },
  { name: "JavaScript", cat: "Languages", level: "Expert", desc: "Builds responsive client-side UIs and interactive Canvas simulations.", color: "#38bdf8", shadow: "rgba(56,189,248,0.5)" },
  { name: "C++", cat: "Languages", level: "Proficient", desc: "Object-oriented structures, algorithmic solutions, and memory control.", color: "#10b981", shadow: "rgba(16,185,129,0.5)" },
  { name: "C", cat: "Languages", level: "Proficient", desc: "System architectures, file storage APIs, and compiler foundations.", color: "#ef4444", shadow: "rgba(239,68,68,0.5)" },
  
  // Frontend
  { name: "React", cat: "Frontend", level: "Expert", desc: "Single Page Apps, custom hooks, context stores, and styled design grids.", color: "#ec4899", shadow: "rgba(236,72,153,0.5)" },
  { name: "HTML5 / CSS3", cat: "Frontend", level: "Expert", desc: "Grid styling, custom variables, and responsive layout standards.", color: "#38bdf8", shadow: "rgba(56,189,248,0.5)" },
  { name: "Tailwind CSS", cat: "Frontend", level: "Proficient", desc: "Utility-first layouts, custom spacing scales, and dark-mode overrides.", color: "#a855f7", shadow: "rgba(168,85,247,0.5)" },

  // Tools & DBs
  { name: "Git & GitHub", cat: "Systems", level: "Expert", desc: "Version control branching, actions workflows, and source logs.", color: "#f59e0b", shadow: "rgba(245,158,11,0.5)" },
  { name: "Docker", cat: "Systems", level: "Proficient", desc: "Containerized environments, multi-stage building, and deployment.", color: "#38bdf8", shadow: "rgba(56,189,248,0.5)" },
  { name: "MongoDB", cat: "Systems", level: "Proficient", desc: "NoSQL collection patterns, indices optimizations, and cluster shards.", color: "#10b981", shadow: "rgba(16,185,129,0.5)" },
  { name: "SQL & Relational", cat: "Systems", level: "Proficient", desc: "Relational modeling, primary indices, and custom query procedures.", color: "#a855f7", shadow: "rgba(168,85,247,0.5)" },

  // Soft Skills
  { name: "Problem Solving", cat: "Soft Skills", level: "Expert", desc: "Algorithmic thinking, structural debugging, and code clean-ups.", color: "#f59e0b", shadow: "rgba(245,158,11,0.5)" },
  { name: "Leadership", cat: "Soft Skills", level: "Proficient", desc: "Coordinating hackathons, assigning tasks, and project management.", color: "#10b981", shadow: "rgba(16,185,129,0.5)" }
];

const education = [
  {
    id: "bachelor",
    degree: "Bachelor in Engineering",
    school: "Pathivara Centre For Advanced Studies",
    year: "2022 – PRESENT",
    score: "CGPA: 3.44",
    desc: "Pursuing computer/software engineering. Highly active in technical committees, coordinator of hackathon groups, and regular participant in programming events. Maintained a top tier academic rating of 3.44 CGPA."
  },
  {
    id: "plus2",
    degree: "+2 Science",
    school: "Shree Devi Mavi",
    year: "COMPLETED 2021",
    score: "CGPA: 2.69",
    desc: "Specialized in Physics, Chemistry, and Mathematics. Formed foundational logic in computing systems and participated in regional science challenges."
  },
  {
    id: "see",
    degree: "SEE",
    school: "Little Angels' English School",
    year: "COMPLETED 2019",
    score: "CGPA: 3.65",
    desc: "Secondary Education Examination with distinction. Awarded institutional honors for achievements in mathematics and computer sciences."
  }
];

const hobbies = {
  camera: { title: "Videography & Editing", desc: "Shooting cinematic footage, color grading, and editing high-quality digital videos using Premiere Pro and DaVinci Resolve." },
  easel: { title: "Graphic Design", desc: "Creating modern vector graphics, branding guidelines, layouts, and typography assets using Illustrator and Figma." },
  dumbbell: { title: "Bodybuilding", desc: "Dedicated weight training, muscular endurance workouts, and dietary discipline to foster mental focus and physical resilience." }
};


// ═══════════════════════════════════════════════════════
// STARRY SKY ENGINE
// ═══════════════════════════════════════════════════════

function initStarsCanvas(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  
  let stars = [];
  const count = 100;
  
  function resize() {
    canvas.width = canvas.parentElement.offsetWidth;
    canvas.height = canvas.parentElement.offsetHeight;
    generate();
  }
  
  function generate() {
    stars = [];
    for (let i = 0; i < count; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.5 + 0.5,
        alpha: Math.random(),
        speed: Math.random() * 0.02 + 0.005
      });
    }
  }
  
  function loop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#ffffff";
    
    for (let i = 0; i < stars.length; i++) {
      const s = stars[i];
      s.alpha += s.speed;
      if (s.alpha > 1 || s.alpha < 0) s.speed = -s.speed;
      
      ctx.beginPath();
      ctx.globalAlpha = Math.max(0.1, s.alpha);
      ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      ctx.fill();
    }
    
    ctx.globalAlpha = 1.0;
    requestAnimationFrame(loop);
  }
  
  window.addEventListener("resize", resize);
  resize();
  loop();
}


// ═══════════════════════════════════════════════════════
// GLOWING CUSTOM CURSOR
// ═══════════════════════════════════════════════════════

let cursorX = 0, cursorY = 0;
let targetX = 0, targetY = 0;
const cursor = document.getElementById("cur");

document.addEventListener("mousemove", (e) => {
  targetX = e.clientX;
  targetY = e.clientY;
});

function updateCursor() {
  cursorX += (targetX - cursorX) * 0.16;
  cursorY += (targetY - cursorY) * 0.16;
  cursor.style.left = `${cursorX}px`;
  cursor.style.top = `${cursorY}px`;
  requestAnimationFrame(updateCursor);
}
requestAnimationFrame(updateCursor);

function attachCursorHoverEvents(parent = document) {
  const interactables = parent.querySelectorAll("a, button, .dr, .fw-3d, .skill-glob-3d, .edu-book-3d, .camera-3d-model, .easel-3d-model, .dumbbell-3d-model");
  interactables.forEach(el => {
    el.addEventListener("mouseenter", () => cursor.classList.add("hovered"));
    el.addEventListener("mouseleave", () => cursor.classList.remove("hovered"));
  });
}
attachCursorHoverEvents();


// ═══════════════════════════════════════════════════════
// CAMERA 3D MOUSE PARALLAX TILT & FIRST-PERSON NAVIGATION
// ═══════════════════════════════════════════════════════

let mouseX = 0, mouseY = 0;
let tiltX = 0, tiltY = 0;

let targetYRotation = 0;
let currentYRotation = 0;
let hallwayZOffset = 0;
let targetZOffset = 0;
let isTransitioning = false;

document.addEventListener("mousemove", (e) => {
  if (window.innerWidth < 768) return; // Disable parallax on mobile
  mouseX = (e.clientX / window.innerWidth) - 0.5;
  mouseY = (e.clientY / window.innerHeight) - 0.5;
});

function animateParallax() {
  if (window.innerWidth >= 768) {
    tiltY += (mouseX * -14 - tiltY) * 0.08; 
    tiltX += (mouseY * 10 - tiltX) * 0.08;   
    
    // Smoothly interpolate look-rotation and walking offset
    currentYRotation += (targetYRotation - currentYRotation) * 0.1;
    hallwayZOffset += (targetZOffset - hallwayZOffset) * 0.1;
    
    const activeRoomBox = document.querySelector(".sc.on .room-3d");
    if (activeRoomBox) {
      if (activeRoomBox.id === "hallway-box") {
        if (!isTransitioning) {
          activeRoomBox.style.transform = `translate3d(0, 0, ${hallwayZOffset}px) rotateX(${tiltX}deg) rotateY(${tiltY + currentYRotation}deg)`;
        }
      } else {
        activeRoomBox.style.transform = `rotateX(${tiltX}deg) rotateY(${tiltY}deg)`;
      }
    }
  }
  
  // Proximity Detection action prompt update
  const promptEl = document.getElementById("hall-action-prompt");
  if (promptEl) {
    if (hallScreen.classList.contains("on") && !isTransitioning && window.innerWidth >= 768) {
      if (hallwayZOffset > 100 && hallwayZOffset < 280) {
        promptEl.innerHTML = `
          <div style="margin-bottom:6px; font-size:0.65rem; color:#94a3b8; text-transform:uppercase; font-family:'JetBrains Mono', monospace;">Proximity Action</div>
          <div style="color:#38bdf8; font-size:0.95rem; font-weight:800; margin-bottom:10px; font-family:'JetBrains Mono', monospace;">You are standing near:</div>
          <div style="display:flex; gap:12px; justify-content:center;">
            <button class="prompt-btn" onclick="triggerRoomTransition('projects')">💼 PROJECTS</button>
            <button class="prompt-btn" onclick="triggerRoomTransition('education')">🎓 EDUCATION</button>
          </div>
        `;
        promptEl.classList.add("show");
      } else if (hallwayZOffset > 420 && hallwayZOffset < 560) {
        promptEl.innerHTML = `
          <div style="margin-bottom:6px; font-size:0.65rem; color:#94a3b8; text-transform:uppercase; font-family:'JetBrains Mono', monospace;">Proximity Action</div>
          <div style="color:#38bdf8; font-size:0.95rem; font-weight:800; margin-bottom:10px; font-family:'JetBrains Mono', monospace;">You are standing near:</div>
          <div style="display:flex; gap:12px; justify-content:center;">
            <button class="prompt-btn" onclick="triggerRoomTransition('skills')">🎨 TECH SKILLS</button>
            <button class="prompt-btn" onclick="triggerRoomTransition('hobbies')">🎮 HOBBIES</button>
          </div>
        `;
        promptEl.classList.add("show");
      } else if (hallwayZOffset >= 560) {
        promptEl.innerHTML = `
          <div style="margin-bottom:6px; font-size:0.65rem; color:#94a3b8; text-transform:uppercase; font-family:'JetBrains Mono', monospace;">Proximity Action</div>
          <div style="color:#38bdf8; font-size:0.95rem; font-weight:800; margin-bottom:10px; font-family:'JetBrains Mono', monospace;">End of Corridor:</div>
          <div style="display:flex; gap:12px; justify-content:center;">
            <button class="prompt-btn" onclick="triggerRoomTransition('contact')">🌌 EXIT BACKYARD</button>
          </div>
        `;
        promptEl.classList.add("show");
      } else {
        promptEl.classList.remove("show");
      }
    } else {
      promptEl.classList.remove("show");
    }
  }
  
  requestAnimationFrame(animateParallax);
}
requestAnimationFrame(animateParallax);


// ═══════════════════════════════════════════════════════
// PAGE TRANSITIONS & DOORS STATE CONTROLLER
// ═══════════════════════════════════════════════════════

const extScreen = document.getElementById("ext");
const hallScreen = document.getElementById("hall");
const roomScreen = document.getElementById("room");
const contactScreen = document.getElementById("contact-room");
const houseWrapper = document.getElementById("house-wrapper");
const frontDoor = document.getElementById("front-door");
const doorGlow = document.getElementById("door-glow-spill");
const hallwayBox = document.getElementById("hallway-box");
const roomBox = document.getElementById("room-3d-box");

// 1. Enter house from exterior door
frontDoor.addEventListener("click", () => {
  const doorLeaf = document.getElementById("door-leaf");
  doorLeaf.style.transformOrigin = "241px 294px";
  doorLeaf.style.transition = "transform 1.4s cubic-bezier(0.25, 1, 0.5, 1)";
  doorLeaf.style.transform = "rotateY(-95deg)";
  doorGlow.style.opacity = "0.9";
  doorGlow.style.transition = "opacity 0.6s";
  
  houseWrapper.style.transformOrigin = "270px 294px";
  houseWrapper.style.transition = "transform 2.2s cubic-bezier(0.5, 0, 0.25, 1)";
  houseWrapper.style.transform = "scale(8.5)";
  extScreen.style.transition = "opacity 1.8s ease-in";
  extScreen.style.opacity = "0";
  
  setTimeout(() => {
    extScreen.classList.remove("on");
    hallScreen.classList.add("on");
    hallScreen.style.opacity = "0";
    setTimeout(() => {
      hallScreen.style.opacity = "1";
    }, 50);
  }, 1800);
});

// Global Room Transition Handler (Click/Proximity Action / Enter key triggered)
window.triggerRoomTransition = function(roomType) {
  if (isTransitioning) return;
  isTransitioning = true;
  
  // Hide action prompt immediately
  const prompt = document.getElementById("hall-action-prompt");
  if (prompt) prompt.classList.remove("show");
  
  // Swing the door open
  const door = document.querySelector(`#hallway-box .dr[data-room="${roomType}"]`);
  if (door) {
    door.style.transformOrigin = "left center";
    door.style.transition = "transform 1.2s ease";
    door.style.transform = "rotateY(-105deg)";
  }
  
  // Animate first person walk-up on desktop
  if (window.innerWidth >= 768) {
    let zoomZ = 600;
    let zoomY = 0;
    if (roomType === "projects") { zoomZ = 180; zoomY = 65; }
    else if (roomType === "education") { zoomZ = 180; zoomY = -65; }
    else if (roomType === "skills") { zoomZ = 520; zoomY = 65; }
    else if (roomType === "hobbies") { zoomZ = 520; zoomY = -65; }
    
    targetZOffset = zoomZ;
    targetYRotation = zoomY;
    
    setTimeout(() => {
      hallwayBox.style.transition = "transform 1.2s cubic-bezier(0.25, 1, 0.4, 1)";
      hallwayBox.style.transform = `translate3d(0, 0, ${zoomZ + 120}px) rotateY(${zoomY}deg) scale(1.3)`;
    }, 50);
  }
  
  hallScreen.style.transition = "opacity 1.2s ease-in-out";
  setTimeout(() => {
    hallScreen.style.opacity = "0";
  }, 300);
  
  setTimeout(() => {
    if (door) door.style.transform = "";
    hallwayBox.style.transition = "";
    hallwayBox.style.transform = "";
    
    hallScreen.classList.remove("on");
    
    if (roomType === "contact") {
      contactScreen.classList.add("on");
      contactScreen.style.opacity = "0";
      setTimeout(() => contactScreen.style.opacity = "1", 50);
    } else {
      loadRoom(roomType);
    }
  }, 1400);
};

// 2. Door clicks in the 3D hallway
document.querySelectorAll("#hallway-box .dr").forEach(door => {
  door.addEventListener("click", (e) => {
    const roomType = door.getAttribute("data-room");
    triggerRoomTransition(roomType);
  });
});

// Keyboard controls for first-person walk-through
window.addEventListener("keydown", (e) => {
  if (!hallScreen.classList.contains("on") || isTransitioning) return;
  if (e.key === "Enter" || e.key === " ") {
    const activePromptBtn = document.querySelector("#hall-action-prompt.show .prompt-btn");
    if (activePromptBtn) {
      e.preventDefault();
      activePromptBtn.click();
    }
  }
  if (e.key === "ArrowUp" || e.key === "w" || e.key === "W") {
    targetZOffset = Math.min(600, targetZOffset + 60);
  } else if (e.key === "ArrowDown" || e.key === "s" || e.key === "S") {
    targetZOffset = Math.max(0, targetZOffset - 60);
  } else if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") {
    targetYRotation = 35;
  } else if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") {
    targetYRotation = -35;
  }
});

window.addEventListener("keyup", (e) => {
  if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A" ||
      e.key === "ArrowRight" || e.key === "d" || e.key === "D") {
    targetYRotation = 0;
  }
});

// On-screen navigation control button bindings
document.getElementById("hall-btn-forward").addEventListener("click", () => {
  if (isTransitioning) return;
  targetZOffset = Math.min(600, targetZOffset + 85);
});
document.getElementById("hall-btn-backward").addEventListener("click", () => {
  if (isTransitioning) return;
  targetZOffset = Math.max(0, targetZOffset - 85);
});

const btnLeft = document.getElementById("hall-btn-left");
btnLeft.addEventListener("mousedown", () => { if (!isTransitioning) targetYRotation = 35; });
btnLeft.addEventListener("mouseup", () => { targetYRotation = 0; });
btnLeft.addEventListener("mouseleave", () => { targetYRotation = 0; });
btnLeft.addEventListener("touchstart", (e) => { e.preventDefault(); if (!isTransitioning) targetYRotation = 35; });
btnLeft.addEventListener("touchend", () => { targetYRotation = 0; });

const btnRight = document.getElementById("hall-btn-right");
btnRight.addEventListener("mousedown", () => { if (!isTransitioning) targetYRotation = -35; });
btnRight.addEventListener("mouseup", () => { targetYRotation = 0; });
btnRight.addEventListener("mouseleave", () => { targetYRotation = 0; });
btnRight.addEventListener("touchstart", (e) => { e.preventDefault(); if (!isTransitioning) targetYRotation = -35; });
btnRight.addEventListener("touchend", () => { targetYRotation = 0; });

document.getElementById("hall-btn-outside").addEventListener("click", () => {
  if (isTransitioning) return;
  goOutside();
});

function goOutside() {
  isTransitioning = true;
  hallScreen.style.transition = "opacity 0.8s ease-in-out";
  hallScreen.style.opacity = "0";
  
  setTimeout(() => {
    hallScreen.classList.remove("on");
    extScreen.classList.add("on");
    extScreen.style.opacity = "0";
    
    houseWrapper.style.transition = "transform 1.6s cubic-bezier(0.25, 1, 0.5, 1)";
    houseWrapper.style.transform = "scale(1)";
    
    const doorLeaf = document.getElementById("door-leaf");
    if (doorLeaf) {
      doorLeaf.style.transform = "rotateY(0deg)";
    }
    doorGlow.style.opacity = "0";
    
    setTimeout(() => {
      extScreen.style.opacity = "1";
      targetZOffset = 0;
      hallwayZOffset = 0;
      targetYRotation = 0;
      currentYRotation = 0;
      isTransitioning = false;
    }, 400);
  }, 800);
}

// 3. Return navigation hooks
document.getElementById("room-back-btn").addEventListener("click", () => {
  roomScreen.classList.remove("on");
  hallScreen.classList.add("on");
  hallScreen.style.opacity = "0";
  setTimeout(() => {
    hallScreen.style.opacity = "1";
    targetZOffset = 0;
    hallwayZOffset = 0;
    targetYRotation = 0;
    currentYRotation = 0;
    isTransitioning = false;
  }, 50);
});

document.getElementById("contact-back-btn").addEventListener("click", () => {
  contactScreen.classList.remove("on");
  hallScreen.classList.add("on");
  hallScreen.style.opacity = "0";
  setTimeout(() => {
    hallScreen.style.opacity = "1";
    targetZOffset = 0;
    hallwayZOffset = 0;
    targetYRotation = 0;
    currentYRotation = 0;
    isTransitioning = false;
  }, 50);
});


// ═══════════════════════════════════════════════════════
// ROOM 3D RENDER ENGINE (DYNAMIC DOM POPULATOR)
// ═══════════════════════════════════════════════════════

let projectsZOffset = 0;

function loadRoom(type) {
  roomScreen.classList.add("on");
  roomScreen.style.opacity = "0";
  setTimeout(() => roomScreen.style.opacity = "1", 50);
  
  // Set title
  const titleMap = {
    "projects": "PROJECTS ROOM",
    "skills": "SKILLS PALETTE",
    "education": "EDUCATION STUDY",
    "hobbies": "HOBBIES ROOM"
  };
  document.getElementById("room-title").innerText = titleMap[type] || "ROOM";
  
  const hintMap = {
    "projects": "Scroll mouse wheel to walk down the bus topology line in 3D.",
    "skills": "Hover on paint blobs on the 3D mixing table to review proficiencies.",
    "education": "Click on any vintage book on the study shelf to review academic history.",
    "hobbies": "Click on the video camera, easel, or barbell equipment to check details."
  };
  document.getElementById("room-hint").innerText = hintMap[type] || "Explore the room in 3D.";

  // Reset scroll state
  projectsZOffset = 0;
  roomBox.removeEventListener("wheel", handleProjectsScroll);
  
  // Render structure
  if (type === "projects") {
    renderProjectsRoom();
  } else if (type === "skills") {
    renderSkillsRoom();
  } else if (type === "education") {
    renderEducationRoom();
  } else if (type === "hobbies") {
    renderHobbiesRoom();
  }
  
  attachCursorHoverEvents(roomBox);
}

// Named scroll handler to avoid cloning node references
function handleProjectsScroll(e) {
  if (window.innerWidth < 768) return; // standard vertical scroll handles mobile
  e.preventDefault();
  
  // Zoom speed
  projectsZOffset += e.deltaY * 0.72;
  // Bound scroll from z = 0 (entrance) to z = max depth + 400
  const maxDepth = (projects.length * 220) + 200;
  projectsZOffset = Math.max(0, Math.min(maxDepth, projectsZOffset));
  
  const busScene = document.getElementById("bus-scene");
  if (busScene) {
    busScene.style.transform = `translateZ(${projectsZOffset}px)`;
  }
}

// ── PROJECTS: 3D BUS TOPOLOGY ──
function renderProjectsRoom() {
  let html = `
    <!-- FLOOR -->
    <div class="room-wall floor"></div>
    
    <!-- CEILING -->
    <div class="room-wall ceiling">
      <div class="ceiling-bus-wire"></div>
    </div>
    
    <!-- LEFT WALL (Blueprints Decor) -->
    <div class="room-wall left">
      <div class="server-rack" style="left: 140px; top: 18vh;"></div>
      <div class="server-rack" style="left: 540px; top: 18vh;"></div>
    </div>
    
    <!-- RIGHT WALL (Monitors Decor) -->
    <div class="room-wall right">
      <div class="server-rack" style="left: 140px; top: 18vh;"></div>
      <div class="server-rack" style="left: 540px; top: 18vh;"></div>
    </div>
    
    <!-- BACK WALL -->
    <div class="room-wall back">
      <div class="hallway-end-window"></div>
    </div>
    
    <!-- SCENE CONTAINER FOR BUS LINE & NODES -->
    <div class="bus-scene-3d" id="bus-scene">
  `;
  
  // Place frames at alternating X coordinates (left/right of center line) and staggered Z coordinates (depth)
  projects.forEach((proj, idx) => {
    const isLeft = idx % 2 === 0;
    const xCoord = isLeft ? "calc(50vw - 230px)" : "calc(50vw + 60px)";
    const yCoord = "15vh";
    const zDepth = -(idx * 220) - 150; // starts at z = -150px, steps back by 220px per item
    const stringHeight = 100 + (idx % 3) * 30; // alternating heights
    
    html += `
      <div class="fw-3d" style="left: ${xCoord}; top: ${yCoord}; transform: translateZ(${zDepth}px);" data-index="${idx}">
        <div class="string-3d" style="height: ${stringHeight}px;"></div>
        <div class="frame-3d">
          <div class="f-icon-3d">${proj.icon}</div>
          <div class="f-title-3d">${proj.title}</div>
          <div class="f-tags-3d">
            ${proj.tags.map(t => `<span class="ftag-3d">${t}</span>`).join("")}
          </div>
        </div>
      </div>
    `;
  });
  
  html += `</div>`;
  roomBox.innerHTML = html;
  
  // Set up mouse wheel scroll listener for Z translation walk-through directly on roomBox
  roomBox.addEventListener("wheel", handleProjectsScroll, { passive: false });
  
  // Hover & Click Bindings
  const floatingCard = document.getElementById("floating-card");
  roomBox.querySelectorAll(".fw-3d").forEach(node => {
    const idx = parseInt(node.getAttribute("data-index"));
    const proj = projects[idx];
    
    node.addEventListener("mouseenter", () => {
      floatingCard.querySelector(".float-title").innerText = proj.title;
      floatingCard.querySelector(".float-desc").innerText = proj.desc;
      floatingCard.classList.add("show");
    });
    
    node.addEventListener("mousemove", (e) => {
      floatingCard.style.left = `${e.clientX + 16}px`;
      floatingCard.style.top = `${e.clientY + 16}px`;
    });
    
    node.addEventListener("mouseleave", () => {
      floatingCard.classList.remove("show");
    });
    
    node.addEventListener("click", () => {
      openModal(proj);
    });
  });
}

// ── SKILLS: 3D MIXING PALETTE ──
function renderSkillsRoom() {
  let html = `
    <!-- FLOOR -->
    <div class="room-wall floor">
      <!-- Artist palette layout lying flat on floor -->
      <div class="skills-table-3d">
        ${skills.map((s, idx) => `
          <div class="skill-glob-3d" 
               style="--color: ${s.color}; --shadow-color: ${s.shadow};"
               data-index="${idx}">
            ${s.name}
          </div>
        `).join("")}
      </div>
    </div>
    
    <!-- CEILING -->
    <div class="room-wall ceiling"></div>
    
    <!-- LEFT WALL (Design guidelines posters) -->
    <div class="room-wall left">
      <div class="painting" style="left: 200px; top: 25vh; width: 140px; height: 180px; background: linear-gradient(135deg, #1e293b, #0c0f1d); border-color:#38bdf8;"></div>
      <div class="painting" style="left: 540px; top: 25vh; width: 140px; height: 180px; background: linear-gradient(135deg, #1e293b, #0c0f1d); border-color:#10b981;"></div>
    </div>
    
    <!-- RIGHT WALL (Framework certifications) -->
    <div class="room-wall right">
      <div class="painting" style="left: 200px; top: 25vh; width: 140px; height: 180px; background: linear-gradient(135deg, #1e293b, #0c0f1d); border-color:#f59e0b;"></div>
      <div class="painting" style="left: 540px; top: 25vh; width: 140px; height: 180px; background: linear-gradient(135deg, #1e293b, #0c0f1d); border-color:#a855f7;"></div>
    </div>
    
    <!-- BACK WALL -->
    <div class="room-wall back">
      <!-- Central Blackboard to review stats -->
      <div class="skills-info-box-3d">
        <div class="skills-info-title-3d" id="sk-title">SKILLS TABLE</div>
        <div class="skills-info-level-3d" id="sk-level">// Hover color blobs to inspect proficiencies</div>
        <p id="sk-desc" style="color: #64748b; font-size: 0.76rem; margin-top: 0.6rem; line-height: 1.45;">
          Each paint glob on the 3D mixing table represents a core programming tool, framework, or soft skill.
        </p>
      </div>
    </div>
  `;
  
  roomBox.innerHTML = html;
  
  // Hover updates
  const skTitle = document.getElementById("sk-title");
  const skLevel = document.getElementById("sk-level");
  const skDesc = document.getElementById("sk-desc");
  
  roomBox.querySelectorAll(".skill-glob-3d").forEach(glob => {
    glob.addEventListener("mouseenter", () => {
      const idx = parseInt(glob.getAttribute("data-index"));
      const s = skills[idx];
      skTitle.innerText = s.name;
      skTitle.style.color = s.color;
      skLevel.innerText = `${s.cat} // Level: ${s.level}`;
      skDesc.innerText = s.desc;
    });
  });
}

// ── EDUCATION: 3D SHELF & STUDY DESK ──
function renderEducationRoom() {
  let html = `
    <!-- FLOOR -->
    <div class="room-wall floor">
      <div class="hall-carpet" style="width: 500px; height: 400px; top: 150px; background: radial-gradient(circle, #27160c 20%, transparent 60%); border: 1px solid rgba(139,92,26,0.15);"></div>
    </div>
    
    <!-- CEILING -->
    <div class="room-wall ceiling"></div>
    
    <!-- LEFT/RIGHT WALLS -->
    <div class="room-wall left"></div>
    <div class="room-wall right"></div>
    
    <!-- BACK WALL (Wooden Bookshelf) -->
    <div class="room-wall back">
      <div class="bookshelf-3d">
        <div class="shelf-row">
          ${education.map((edu, idx) => {
            let colorClass = "bachelor";
            if (edu.id === "plus2") colorClass = "science";
            if (edu.id === "see") colorClass = "see";
            
            return `
              <div class="edu-book-3d ${colorClass}" data-id="${edu.id}">
                <span style="font-size: 0.55rem; color: #fbbf24; font-family: 'JetBrains Mono', monospace; font-weight: 600;">
                  ${edu.year.split(" ")[0]}
                </span>
                <span style="font-size: 0.72rem; font-weight: 700; color: #f1f5f9; line-height: 1.35;">
                  ${edu.degree.length > 12 ? edu.degree.slice(0, 10) + ".." : edu.degree}
                </span>
                <span style="font-size: 0.52rem; color: #cbd5e1;">${edu.score}</span>
              </div>
            `;
          }).join("")}
        </div>
      </div>
      
      <!-- Cozy desk study display panel -->
      <div class="desk-study-panel" id="edu-panel">
        <h3 id="edu-degree" style="font-family: 'Cinzel', serif; color: #fbbf24; font-size: 1rem; margin-bottom: 0.2rem;">Bachelor in Engineering</h3>
        <div id="edu-school" style="font-size: 0.74rem; color: #f1f5f9; font-weight: 600; margin-bottom: 0.5rem;">Pathivara Centre For Advanced Studies</div>
        <p id="edu-desc" style="font-size: 0.74rem; color: #94a3b8; line-height: 1.5;">Click a book on the library shelf above to pull its academic credentials.</p>
      </div>
    </div>
  `;
  
  roomBox.innerHTML = html;
  
  const eduPanel = document.getElementById("edu-panel");
  const eduDegree = document.getElementById("edu-degree");
  const eduSchool = document.getElementById("edu-school");
  const eduDesc = document.getElementById("edu-desc");
  
  roomBox.querySelectorAll(".edu-book-3d").forEach(book => {
    book.addEventListener("click", () => {
      // Remove selected class
      roomBox.querySelectorAll(".edu-book-3d").forEach(b => b.classList.remove("selected"));
      
      book.classList.add("selected");
      const id = book.getAttribute("data-id");
      const edu = education.find(e => e.id === id);
      
      if (edu) {
        eduPanel.classList.add("active");
        eduDegree.innerText = edu.degree;
        eduSchool.innerText = `${edu.school} • ${edu.year} • ${edu.score}`;
        eduDesc.innerText = edu.desc;
      }
    });
  });
}

// ── HOBBIES: 3D GALLERY EQUIPMENT ──
function renderHobbiesRoom() {
  let html = `
    <!-- FLOOR -->
    <div class="room-wall floor">
      <!-- 3D gym dumbbell rack standing on floor -->
      <div class="dumbbell-3d-model" data-key="dumbbell">🏋️</div>
    </div>
    
    <!-- CEILING -->
    <div class="room-wall ceiling"></div>
    
    <!-- LEFT WALL (Video Camera on Tripod) -->
    <div class="room-wall left">
      <div class="camera-3d-model" data-key="camera">📷</div>
    </div>
    
    <!-- RIGHT WALL (Painting on Easel) -->
    <div class="room-wall right">
      <div class="easel-3d-model" data-key="easel">🎨</div>
    </div>
    
    <!-- BACK WALL -->
    <div class="room-wall back">
      <div class="hobbies-info-board">
        <div class="hobbies-board-title" id="hb-title">HOBBY CABIN</div>
        <p class="hobbies-board-desc" id="hb-desc">
          Click any equipment placed inside the 3D room (the tripod camera, artist easel, or floor dumbbell) to inspect my interests.
        </p>
      </div>
    </div>
  `;
  
  roomBox.innerHTML = html;
  
  const hbTitle = document.getElementById("hb-title");
  const hbDesc = document.getElementById("hb-desc");
  
  roomBox.querySelectorAll(".camera-3d-model, .easel-3d-model, .dumbbell-3d-model").forEach(model => {
    model.addEventListener("click", () => {
      const key = model.getAttribute("data-key");
      const data = hobbies[key];
      if (data) {
        hbTitle.innerText = data.title;
        hbDesc.innerText = data.desc;
      }
    });
  });
}


// ═══════════════════════════════════════════════════════
// DETAILS MODAL SYSTEM
// ═══════════════════════════════════════════════════════

const modal = document.getElementById("modal");
const modalClose = document.getElementById("modal-close-btn");
const mIcon = document.getElementById("modal-icon");
const mTitle = document.getElementById("modal-title");
const mDesc = document.getElementById("modal-desc");
const mTags = document.getElementById("modal-tags");
const mLink = document.getElementById("modal-link");

function openModal(proj) {
  modal.classList.add("show");
  mIcon.innerText = proj.icon;
  mTitle.innerText = proj.title;
  mDesc.innerText = proj.desc;
  
  mTags.innerHTML = proj.tags.map(t => `<span class="modal-tag">${t}</span>`).join("");
  mLink.href = proj.link;
  
  cursor.classList.remove("hovered");
}

modalClose.addEventListener("click", () => {
  modal.classList.remove("show");
});

window.addEventListener("click", (e) => {
  if (e.target === modal) {
    modal.classList.remove("show");
  }
});


// ═══════════════════════════════════════════════════════
// APPLICATION INITIALIZATION
// ═══════════════════════════════════════════════════════

document.addEventListener("DOMContentLoaded", () => {
  initStarsCanvas("star-canvas");
  initStarsCanvas("balcony-star-canvas");
});
